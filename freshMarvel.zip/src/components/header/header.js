import HeaderWrapper from "./header-wrapper/header-wrapper";
import '../header/header.scss'
const Header = () => {



    return (
        <div className="header">
            <HeaderWrapper />
        </div>
    )
}

export default Header;