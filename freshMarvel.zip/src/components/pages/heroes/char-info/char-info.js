import './char-info.scss';

import CharInfoItem from './charinfo-item/charinfo-item'

const CharInfo = () => {


        return (
       <div className="char__info">
          <CharInfoItem /> 
       </div>
          
      
          
            
  );
}


export default CharInfo