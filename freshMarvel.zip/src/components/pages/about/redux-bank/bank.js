import './bank.scss';
import { useDispatch, useSelector } from 'react-redux';
import { useState } from 'react';
import BalanceDisplay  from './accounts/BalanceDisplay';
const Bank =()=>{

const [value, setValue] = useState('');

const [dataAccounts, setDataAccounts] = useState([{
    id: 1, login: 'Alex', password: '311',isLogin: false,
},]);
const [newUser, setNewUser] = useState({
    login: '',
    password: '',
    isLogin: false,
});



const dispatch = useDispatch();
const counter = useSelector(state => state.counter.cash);

const addCash = () => { 
    dispatch({type:"ADD_CASH", payload: Number(value)});
    console.log('отрабатывает');
    console.log(value)
}
const getCash = () => {
    dispatch({type: "WITHDRAW_CASH", payload: Number(value)})
}
const createNewPerson = (e) => {
    e.preventDefault();
   const {name, value} = e.target;
   setNewUser({...newUser, [name]: value, isLogin: false, id: dataAccounts.length + 1});
   

   console.log(newUser);

}
const addNewPerson = () => {
    localStorage.setItem('userData', dataAccounts);
    setDataAccounts((prevUser) => [...prevUser, newUser]);
    console.log(dataAccounts)
    
}
    return (
        <div className='bank'>
            <form className='person' onSubmit={createNewPerson}>
                <label className='input'>
                    <input type='text' placeholder='enter name' name='login' onChange={createNewPerson}/>
                </label>
                <label className='input'>
                    <input type='text' placeholder='enter password' name='password' onChange={createNewPerson}/>
                </label>
                <button onClick={addNewPerson}style={{marginTop: '10px'}}>Create New Person</button>
            </form>
            {/* <div className='operations'>
             <h2>counter: <BalanceDisplay /></h2>
                <label className='input'>
                    <input 
                    onChange={(e) => setValue(e.target.value)}
                    type="number" 
                    placeholder="type to ADD" 
                  />
                    <button onClick={addCash}>ADD</button>
                </label>
                <label className='input'>
                    <input 
                    onChange={(e) => setValue(e.target.value)}
                    type="number" 
                    placeholder="type to WITHDRAW" />
                    <button onClick={getCash}>GET</button>
                </label>
            
            </div> */}

        </div>
        
    )
}

export default Bank;