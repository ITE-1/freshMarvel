


const NewPerson = () => {



    return (
        <div ></div>
    )
}