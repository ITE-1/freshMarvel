import Bank from "./redux-bank/bank"


const About = () => {




    return (
        <div style={{paddingTop: '50px'}}>
            <h1>Bank</h1>
            <Bank />
        
        </div>
    )
}


export default About