import '../spiner/spiner.scss'

const Spinner = () => {


    return (
        <div className='loader__display'>
        <span className="loader"></span>
        </div>
        
    )
}


export default Spinner;